'use strict';

angular.module('tutorialApp', []);
