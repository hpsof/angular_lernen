angular_lernen
==============

zum ueben /frisch angefangen: 10.11.2014 10:55:58
- http://angularjs.de/artikel/angularjs-tutorial-deutsch durchgearbeitet


lokal einmalig:
- git pull -u  git@github.com:hpsof/angular_lernen.git
- git push -u  git@github.com:hpsof/angular_lernen.git

